# BillPay - Nigerian Bill Payment Platform

A production-ready full-stack web application for buying airtime and data in Nigeria with admin dashboard, manual fund approval via Telegram bot, and PWA support.

## Features

### 🎯 User Features
- User authentication with bcrypt password hashing & JWT (1hr expiry)
- Wallet balance management
- Buy airtime from MTN, Airtel, Glo, 9Mobile
- Buy data plans from all networks
- Manual wallet funding via bank transfer with screenshot upload
- Transaction history with status tracking
- PDF receipt download with QR code verification
- PWA: Installable on mobile devices

### 👨‍💼 Admin Features
- Separate admin login with JWT (15min expiry)
- View all users and their wallet balances
- View dashboard stats: total users, total wallet balance, daily sales
- Manual deposit approval via Telegram bot
- Update BitraHQ API key from admin panel

### 🤖 Telegram Bot Features
- Automatic notifications to all admins for new fund requests
- Photo verification of bank transfer receipt
- Approve/Reject buttons with race condition prevention
- Admin management: `/addadmin`, `/listadmin`, `/removeadmin` commands
- API key management: `/setapikey` command
- Database transaction + FOR UPDATE locks for double-approval prevention

### 📱 PWA Features
- Installable on iOS and Android
- Offline caching of static assets
- Custom app icon and splash screen
- "Add to Home Screen" prompt

## Tech Stack

### Backend
- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: PostgreSQL
- **Authentication**: JWT + bcryptjs
- **File Upload**: Multer + Cloudinary
- **PDF Generation**: PDFKit
- **Telegram**: Telegraf
- **API Integration**: Axios

### Frontend
- **Markup**: Vanilla HTML5
- **Styling**: Tailwind CSS (CDN)
- **Scripts**: Vanilla JavaScript + Axios
- **PWA**: Service Worker + Manifest

## Installation

### Prerequisites
- Node.js (v14+)
- PostgreSQL (v12+)
- Telegram Bot (from BotFather)
- Cloudinary account
- BitraHQ API key

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/billpay.git
cd billpay
```

### 2. Install Dependencies
```bash
cd backend
npm install
```

### 3. Setup Database
```bash
# Create PostgreSQL database
createdb billpay

# Run migrations
npm run migrate
```

### 4. Configure Environment
```bash
# Copy example env
cp .env.example .env

# Edit .env with your credentials
nano .env
```

Required environment variables:
```bash
DATABASE_URL=postgresql://user:password@localhost:5432/billpay
JWT_SECRET=your-secret-key-here
BITRA_API_KEY=ef209f45e59848126a807ef654d36e9c
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_ADMIN_CHAT_ID=your_chat_id
CLOUDINARY_CLOUD_NAME=your_cloud
CLOUDINARY_API_KEY=your_key
CLOUDINARY_API_SECRET=your_secret
ADMIN_EMAIL=admin@billpay.com
ADMIN_PASSWORD=ChangeMe@2024
```

### 5. Setup Telegram Webhook
Get your bot token from BotFather, then set webhook:

```bash
curl -X POST https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/setWebhook \
  -H 'Content-Type: application/json' \
  -d '{
    "url": "https://yourdomain.com/api/telegram/webhook?secret={TELEGRAM_WEBHOOK_SECRET}",
    "allowed_updates": ["message", "callback_query"]
  }'
```

### 6. Start Server
```bash
# Development
npm run dev

# Production
npm start
```

Server runs on `http://localhost:5000`

## API Documentation

### Authentication
```bash
# User Signup
POST /api/auth/signup
Body: { email, name, username, password }

# User Login
POST /api/auth/login
Body: { email, password }
Response: { token, user }

# Admin Login (15min expiry)
POST /api/auth/admin-login
Body: { email, password }
Response: { token, admin }

# Get Current User
GET /api/auth/me
Headers: Authorization: Bearer {token}
```

### Wallet
```bash
# Get Balance
GET /api/wallet/balance
Headers: Authorization: Bearer {token}

# Manual Fund Request
POST /api/wallet/manual-fund
Headers: Authorization: Bearer {token}
Body: { amount, user_note, screenshot (file) }
```

### Airtime
```bash
# Buy Airtime
POST /api/airtime/buy
Headers: Authorization: Bearer {token}
Body: { network, phone, amount }
Response: { transaction with ref_id, status }
```

### Data
```bash
# Get Data Plans
GET /api/data/plans?network=MTN
Headers: Authorization: Bearer {token}

# Buy Data
POST /api/data/buy
Headers: Authorization: Bearer {token}
Body: { network, phone, plan (JSON) }
Response: { transaction }
```

### Transactions
```bash
# Get User Transactions
GET /api/transactions
Headers: Authorization: Bearer {token}

# Download Receipt PDF
GET /api/transactions/{id}/receipt
Headers: Authorization: Bearer {token}
```

### Admin
```bash
# Get All Users
GET /api/admin/users
Headers: Authorization: Bearer {adminToken}

# Get Pending Deposits
GET /api/admin/pending-deposits
Headers: Authorization: Bearer {adminToken}

# Approve Deposit
POST /api/admin/approve/{depositId}
Headers: Authorization: Bearer {adminToken}

# Reject Deposit
POST /api/admin/reject/{depositId}
Headers: Authorization: Bearer {adminToken}
Body: { reason }

# Get Stats
GET /api/admin/stats
Headers: Authorization: Bearer {adminToken}

# Update API Key
POST /api/admin/update-api-key
Headers: Authorization: Bearer {adminToken}
Body: { apiKey }
```

### Telegram
```bash
# Webhook (automatic)
POST /api/telegram/webhook?secret={TELEGRAM_WEBHOOK_SECRET}
```

## Telegram Bot Commands

Available to admins only:

| Command | Description | Example |
|---------|-------------|---------|
| `/addadmin` | Add new admin | `/addadmin 123456789` |
| `/listadmins` | List all admins | `/listadmins` |
| `/removeadmin` | Remove admin | `/removeadmin 123456789` |
| `/setapikey` | Update BitraHQ API key | `/setapikey new_api_key_here` |

## Security Features

- ✅ Passwords hashed with bcryptjs (12 rounds)
- ✅ JWT tokens with expiry (1hr user, 15min admin)
- ✅ Rate limiting: 100 requests per 15 minutes
- ✅ Helmet.js security headers
- ✅ CORS protection
- ✅ Input validation with Joi
- ✅ SQL injection prevention (parameterized queries)
- ✅ Double-approval prevention with database locks
- ✅ Telegram webhook secret verification
- ✅ XSS protection via Content Security Policy

## Database Schema

### users
```sql
id (PK) | email (UNIQUE) | name | username (UNIQUE) | password | wallet_balance | role | created_at
```

### transactions
```sql
id (PK) | ref_id (UNIQUE) | user_id (FK) | service | network | phone | amount | status | response (JSONB) | created_at
```

### manual_deposits
```sql
id (PK) | user_id (FK) | amount | bank_name | user_note | screenshot_url | status | admin_note | created_at | approved_at
```

### telegram_admins
```sql
chat_id (PK) | added_by | added_at
```

## Deployment

### Heroku
```bash
# Install Heroku CLI
heroku login
heroku create billpay-app

# Set environment variables
heroku config:set DATABASE_URL=...
heroku config:set JWT_SECRET=...
# ... set all required env vars

# Deploy
git push heroku main
```

### Railway.app
```bash
# Connect GitHub
# Set environment variables in dashboard
# Auto-deploy on push
```

### VPS (Nginx + PM2)
```bash
# Install dependencies
npm install -g pm2

# Start with PM2
pm2 start server.js --name "billpay"

# Setup Nginx reverse proxy
sudo nano /etc/nginx/sites-available/billpay
# Point to localhost:5000

# SSL with Let's Encrypt
sudo certbot --nginx -d billpay.com.ng
```

## Performance Optimization

- Database connection pooling (pg)
- Response compression (Express)
- Cache-Control headers for static assets
- Service Worker offline caching
- Lazy loading of data plans
- Rate limiting to prevent abuse

## Error Handling

All errors return JSON with status code and message:
```json
{
  "message": "Insufficient wallet balance",
  "error": "Details for development"
}
```

HTTP Status Codes:
- 200: Success
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 403: Forbidden
- 404: Not Found
- 500: Server Error

## Testing

### Manual Testing Checklist
- [ ] User signup and email validation
- [ ] Login with correct/wrong credentials
- [ ] Admin login with short expiry
- [ ] Buy airtime with sufficient balance
- [ ] Buy data with plan selection
- [ ] Manual fund with screenshot upload
- [ ] Telegram bot approve/reject
- [ ] PDF receipt generation and QR code
- [ ] Offline app functionality
- [ ] Mobile responsiveness
- [ ] PWA installation

### Postman Collection
Import `postman_collection.json` for API testing

## Troubleshooting

### Database Connection Error
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Check credentials in .env
psql postgresql://user:password@localhost:5432/billpay
```

### Telegram Bot Not Responding
```bash
# Check bot token
curl https://api.telegram.org/bot{TOKEN}/getMe

# Check webhook
curl https://api.telegram.org/bot{TOKEN}/getWebhookInfo

# Re-set webhook
curl -X POST https://api.telegram.org/bot{TOKEN}/setWebhook -H 'Content-Type: application/json' -d '{"url": "https://yourdomain.com/api/telegram/webhook?secret=YOUR_SECRET"}'
```

### Cloudinary Upload Fails
```bash
# Check credentials in .env
# Verify cloud name, API key, API secret
# Ensure upload preset or folder exists
```

### PDF Receipt Not Downloading
```bash
# Check transaction exists and is successful
# Check /api/transactions endpoint returns data
# Verify PDFKit is installed
```

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
- GitHub Issues: https://github.com/yourusername/billpay/issues
- Email: support@billpay.com.ng
- Telegram: @billpay_support

## Roadmap

- [ ] Mobile app (React Native)
- [ ] Email receipts
- [ ] SMS notifications
- [ ] User referral program
- [ ] Subscription plans for frequent buyers
- [ ] International bill payments
- [ ] Multi-currency support
- [ ] Voice USSD alternative

---

**Made with ❤️ by holly sin dev team for Nigerian **